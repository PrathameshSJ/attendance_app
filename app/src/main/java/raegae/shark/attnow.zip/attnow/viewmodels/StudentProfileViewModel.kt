package raegae.shark.attnow.viewmodels

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import raegae.shark.attnow.data.AppDatabase
import raegae.shark.attnow.data.Attendance
import raegae.shark.attnow.data.Student
import raegae.shark.attnow.data.logic.LogicalStudentMerger
import raegae.shark.attnow.data.model.LogicalStudent
import raegae.shark.attnow.data.util.StudentKey
import java.util.Calendar

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class StudentProfileViewModel(
    private val app: Application,
    private val database: AppDatabase,
    private val studentKey: StudentKey
) : ViewModel() {

    /* ---------- navigation ---------- */

    private val _navigateBack = MutableSharedFlow<Unit>()
    val navigateBack = _navigateBack.asSharedFlow()

    private val _deleted = MutableStateFlow(false)
    val deleted: StateFlow<Boolean> = _deleted.asStateFlow()

    /* ---------- logical student ---------- */

    val student: StateFlow<LogicalStudent?> =
        database.studentDao()
            .getAllStudents()
            .map { students ->
                LogicalStudentMerger
                    .merge(students)
                    .firstOrNull { it.key == studentKey }
            }
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5_000),
                null
            )

    /* ---------- attendance (merged timeline) ---------- */

    val attendance: StateFlow<List<Attendance>> =
        student.flatMapLatest { logical ->
            if (logical == null) {
                flowOf(emptyList())
            } else {
                database.attendanceDao()
                    .getAttendanceForStudent(logical.activeEntityId)
            }
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            emptyList()
        )

    /* ---------- actions ---------- */

    fun deleteStudent() {
        viewModelScope.launch {

            database.studentDao().deleteLogicalStudent(
                name = studentKey.name,
                subject = studentKey.subject
            )

            _deleted.value = true
            _navigateBack.emit(Unit)
        }
    }

    /**
     * Renew logic:
     * - If same subject + same days + same times → extend
     * - Else → create new entity
     */
    fun renewStudent(
        newSubject: String,
        newEndDate: Long,
        newDaysOfWeek: List<String>,
        newBatchTimes: Map<String, String>
    ) {
        viewModelScope.launch {

            val entities =
                database.studentDao()
                    .findByNameAndSubject(
                        studentKey.name,
                        studentKey.subject
                    )

            val extendable = entities.firstOrNull { s ->
                s.subject == newSubject &&
                s.daysOfWeek == newDaysOfWeek &&
                s.batchTimes == newBatchTimes
            }

            if (extendable != null) {
                // extend existing subscription
                database.studentDao().update(
                    extendable.copy(
                        subscriptionEndDate = newEndDate
                    )
                )
            } else {
                // create NEW entity
                val start = Calendar.getInstance().timeInMillis

                database.studentDao().insert(
                    Student(
                        name = studentKey.name,
                        subject = newSubject,
                        subscriptionStartDate = start,
                        subscriptionEndDate = newEndDate,
                        daysOfWeek = newDaysOfWeek,
                        batchTimes = newBatchTimes
                    )
                )
            }
        }
    }
}

/* ---------- Factory ---------- */

class StudentProfileViewModelFactory(
    private val application: Application,
    private val studentKey: StudentKey
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudentProfileViewModel::class.java)) {

            val db = AppDatabase.getDatabase(application)

            @Suppress("UNCHECKED_CAST")
            return StudentProfileViewModel(
                app = application,
                database = db,
                studentKey = studentKey
            ) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
