package raegae.shark.attnow.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import raegae.shark.attnow.data.AppDatabase
import raegae.shark.attnow.data.Student
import raegae.shark.attnow.data.StudentDao

class AddStudentViewModel(private val database: AppDatabase) : ViewModel() {

    suspend fun addStudentIfNotExists(name: String, subject: String, subscriptionStartDate: Long, subscriptionEndDate: Long, batchTimes: Map<String, String>, daysOfWeek: List<String>): Boolean {
        val students = database.studentDao().getAllStudents().first()
        val existing = students.find { it.name.equals(name, ignoreCase = true) }
        if (existing != null) return false
        val student = Student(
            name = name,
            subject = subject,
            subscriptionStartDate = subscriptionStartDate,
            subscriptionEndDate = subscriptionEndDate,
            batchTimes = batchTimes,
            daysOfWeek = daysOfWeek
        )
        database.studentDao().insert(student)
        return true
    }

    suspend fun addOrRenewStudent(
        newStudent: Student
    ) {
        val studentDao = database.studentDao()
        val existing = studentDao.findByNameAndSubject(
            newStudent.name,
            newStudent.subject
        )

        if (existing.isEmpty()) {
            studentDao.insert(newStudent)
            return
        }

        val exactMatch = existing.firstOrNull {
            it.daysOfWeek == newStudent.daysOfWeek &&
            it.batchTimes == newStudent.batchTimes
        }

        if (exactMatch != null) {
            // Extend subscription
            studentDao.update(
                exactMatch.copy(
                    subscriptionEndDate = newStudent.subscriptionEndDate
                )
            )
        } else {
            // New subscription entity
            studentDao.insert(newStudent)
        }
    }

}

class AddStudentViewModelFactory(private val application: android.app.Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AddStudentViewModel::class.java)) {
            val database = AppDatabase.getDatabase(application)
            @Suppress("UNCHECKED_CAST")
            return AddStudentViewModel(database) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}