package raegae.shark.attnow.data.export

import org.dhatim.fastexcel.Workbook
import org.dhatim.fastexcel.Worksheet
import org.dhatim.fastexcel.StyleSetter
import java.io.OutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import raegae.shark.attnow.data.AppDatabase
import android.content.Context
import android.net.Uri
import androidx.room.Database
import org.dhatim.fastexcel.reader.ReadableWorkbook
import raegae.shark.attnow.data.Attendance
import java.io.InputStream
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import java.io.FileNotFoundException

data class ExportStudent(
    val id: Int,
    val name: String,
    val batch: String,
    val subject: String,
    val year: Int,
    val attendance: Map<LocalDate, Boolean> // true = present, false = absent
)


class AttendanceExcelExporter(
    private val context: Context,
    private val database: AppDatabase
) {

    suspend fun export(uri: Uri) = withContext(Dispatchers.IO) {

        // 🔹 FORCE data evaluation (VERY IMPORTANT)
        val students = database.studentDao().getAllStudentsOnce()
        val attendance = database.attendanceDao().getAllAttendanceOnce()

        if (students.isEmpty()) return@withContext

        val outputStream =
            context.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("Cannot open output stream")

        Workbook(outputStream, "AttNow", "1.0").use { workbook ->

            val bySubject = students.groupBy { it.subject }
            val attendanceByStudent = attendance.groupBy { it.studentId }

            bySubject.forEach { (subject, subjectStudents) ->

                val sheetName = "${subject}_${LocalDate.now().year}"
                val sheet = workbook.newWorksheet(sheetName)

                writeHeader(sheet)

                var row = 1
                subjectStudents.forEach { student ->
                    writeStudentRow(
                        sheet = sheet,
                        rowIndex = row++,
                        student = student,
                        attendance = attendanceByStudent[student.id].orEmpty()
                    )
                }
            }
        }

        outputStream.flush()
        outputStream.close()
    }

    // ---------- helpers ----------

    private fun writeHeader(sheet: Worksheet) {
        sheet.value(0, 0, "ID")
        sheet.value(0, 1, "Name")
        sheet.value(0, 2, "Batch")
        sheet.value(0, 3, "Month")

        var col = 4
        for (day in 1..31) {
            sheet.value(0, col++, day)
        }
    }

    private fun writeStudentRow(
        sheet: Worksheet,
        rowIndex: Int,
        student: raegae.shark.attnow.data.Student,
        attendance: List<raegae.shark.attnow.data.Attendance>
    ) {
        sheet.value(rowIndex, 0, student.id)
        sheet.value(rowIndex, 1, student.name)
        sheet.value(rowIndex, 2, formatBatchTimes(student.batchTimes))
        sheet.value(rowIndex, 3, "ALL")

        val formatter = DateTimeFormatter.ofPattern("dd/MM")

        attendance.forEach { record ->
            val date = LocalDate.ofEpochDay(record.date / 86_400_000)
            val col = 3 + date.dayOfMonth

            sheet.value(rowIndex, col, date.format(formatter))

            val color = if (record.isPresent) "#92D050" else "#FF6B6B"
            sheet.style(rowIndex, col).fillColor(color)
        }
    }

    private fun formatBatchTimes(batchTimes: Map<String, String>): String {
        if (batchTimes.isEmpty()) return ""
        return batchTimes.entries.joinToString(" | ") { (day, time) ->
            "$day: $time"
        }
    }

}

/* 
class AttendanceExcelExporter(
    private val context: Context,
    private val database: AppDatabase
) {

    private val dateFormatter = DateTimeFormatter.ofPattern("dd/MM")

    fun export(
        students: List<ExportStudent>,
        outputStream: OutputStream
    ) {
        Workbook(outputStream, "AttNow", "1.0").use { workbook ->

            

            // Group by subject + year → sheets
            val sheets = students.groupBy { "${it.subject}_${it.year}" }

            sheets.forEach { (sheetName, sheetStudents) ->
                val sheet = workbook.newWorksheet(sheetName)

                writeHeader(sheet)

                var rowIndex = 1

                sheetStudents.forEach { student ->
                    for (month in 1..12) {
                        writeStudentMonthRow(
                            sheet = sheet,
                            row = rowIndex++,
                            student = student,
                            month = month
                        )
                    }
                }
            }
        }
    }

    private fun writeHeader(sheet: org.dhatim.fastexcel.Worksheet) {
        sheet.value(0, 0, "Student ID")
        sheet.value(0, 1, "Name")
        sheet.value(0, 2, "Batch")
        sheet.value(0, 3, "Month")

        for (day in 1..31) {
            sheet.value(0, 3 + day, day)
        }
    }

    private fun writeStudentMonthRow(
        sheet: org.dhatim.fastexcel.Worksheet,
        row: Int,
        student: ExportStudent,
        month: Int
    ) {
        sheet.value(row, 0, student.id)
        sheet.value(row, 1, student.name)
        sheet.value(row, 2, student.batch)
        sheet.value(row, 3, monthName(month))

        for (day in 1..31) {
            val date = runCatching {
                LocalDate.of(student.year, month, day)
            }.getOrNull() ?: continue

            val status = student.attendance[date] ?: continue

            val col = 3 + day
            sheet.value(row, col, date.format(dateFormatter))

            val styleSetter = sheet.style(row, col)
            if (status) {
                styleSetter.fillColor("92D050") // Present
            } else {
                styleSetter.fillColor("FF4C4C") // Absent
            }
        }
    }

    private fun monthName(month: Int): String =
        java.time.Month.of(month).name.lowercase().replaceFirstChar { it.uppercase() }
}*/
