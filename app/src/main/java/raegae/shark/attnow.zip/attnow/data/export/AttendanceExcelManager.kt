package raegae.shark.attnow.data.export

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import raegae.shark.attnow.data.AppDatabase
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import kotlinx.coroutines.*

class AttendanceExcelManager(
    private val context: Context,
    private val db : AppDatabase
) {

    
    private val importer = AttendanceExcelImporter(context, db)

    /* ---------- EXPORT ---------- */
    suspend fun exportAll(uri: Uri) = withContext(Dispatchers.IO) {
        /*AttendanceExcelExporter(
            context = context,
            database = db
        ).export(uri)*/
    }

    /* ---------- IMPORT ---------- */
    suspend fun import(uri: Uri) {
        importer.import(uri)
    }
}
