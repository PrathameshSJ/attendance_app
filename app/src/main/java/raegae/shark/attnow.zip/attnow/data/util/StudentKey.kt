package raegae.shark.attnow.data.util

/**
 * Stable logical identifier for a student.
 *
 * - name + subject define identity
 * - ID is NOT used (IDs change across renewals / imports)
 */
data class StudentKey(
    val name: String,
    val subject: String
) {

    /** Used for DataStore / persistence */
    fun serialize(): String = "$name||$subject"

    companion object {

        fun fromString(raw: String): StudentKey? {
            val parts = raw.split("||")
            if (parts.size != 2) return null
            return StudentKey(
                name = parts[0],
                subject = parts[1]
            )
        }
    }
}
