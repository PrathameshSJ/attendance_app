package raegae.shark.attnow.ui.home

import raegae.shark.attnow.data.Student

data class StudentWithPin(
    val student: Student,
    val isPinned: Boolean
)
